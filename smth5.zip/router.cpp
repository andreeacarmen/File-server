#include <iostream>
#include <vector>
#include "router.h"
#include "api.h"

/*
class Router {
	public:
	vector< int > routingTable;
	vector< vector < int > > topology;
	vector< int > msgVer;
	Router() {};
	Router(int nr); 
}; */

Router::Router(int nr){
	vector<int> row;
	
	for (int i = 0 ; i<nr; i++)
	{
		for (int j = 0; j<nr; j++)
			row.push_back(-1);
		
		topology.push_back(row);
		routingTable.push_back(-1);
		msgVer.push_back(-1);

		row.clear();
	}
} 

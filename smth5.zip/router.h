#ifndef STUDENT_H
#define STUDENT_H

#include <vector>
#include <string>

using namespace std;


class Router {
	public:
	vector< int > routingTable;
	vector< vector < int > > topology;
	vector< int > msgVer;
	
	Router(int nr); 
}; 

#endif
